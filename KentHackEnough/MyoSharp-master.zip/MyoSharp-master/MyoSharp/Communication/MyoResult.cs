﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyoSharp.Communication
{
    public enum MyoResult
    {
        Success,
        Error,
        ErrorInvalidArgument,
        ErrorRuntime
    }
}
