﻿namespace MyoSharp.Device
{
    public enum StreamEmgType
    {
        Disabled,
        Enabled  
    }
}