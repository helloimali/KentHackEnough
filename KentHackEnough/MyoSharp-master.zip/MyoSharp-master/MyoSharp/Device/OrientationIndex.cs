﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyoSharp.Device
{
    public enum OrientationIndex
    {
        X = 0,
        Y = 1,
        Z = 2,
        W = 3
    }
}
