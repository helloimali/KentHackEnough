﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyoSharp.Device
{
    public enum Arm
    {
        Right,
        Left,
        Unknown
    }
}